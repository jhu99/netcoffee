# DESCRIPTION OF THE DOCUMENTS IN THIS FOLDER.
There are nine files in this folder including README.

###################################################
1. alignment_netcoffee.data

It includes all match-sets of the global alignment outputed by running netcoffee on Dataset-2 with alpha=0.3.

###################################################
2. aveFunSim.result

It includes the semantic similarity scores of each annotated match-sets appeared in the global alignment (alignment_netcoffee.data).

###################################################
3. aveQualified.result

It includes all the qualified match-sets with bpscore > 0.6 or mfscore > 0.8.

###################################################
4. aveUnknown.result

It includes all the (unannotated) match-sets containing uncharacterized proteins which are marked with *.

###################################################
5. matchsets-five.txt

It includes all the match-sets conserved by five species.

###################################################
6. matchsets-four.txt

It includes all the match-sets conserved by four species.

###################################################
7. matchsets-three.txt

It includes all the match-sets conserved by three species.

###################################################
8. matchsets-two.txt

It includes all the match-sets conserved by two species.

###################################################
9. README.txt

DESCRIPTION OF THE DOCUMENTS IN THIS FOLDER.
